$(document).ready(function() {
 
	var panel = $('#togglePanelMain'),
    button = $('#togglePanelSwitcher'),
	imgButton = $('#togglePanelSwitcherButton');
    
	function first(e) {
		//Code for first time click goes here
		e.preventDefault();
		panel.stop().animate({right: 0},200, function(){});
		imgButton.stop().animate({left: -25},200, function(){});
		$(this).one("click", second);
    }
    function second(e) {
        //Code for second time click goes here
		e.preventDefault();
		panel.stop().animate({right: -402},200, function(){});
		imgButton.stop().animate({left: 0},200, function(){});
		$(this).one("click", first);
    }
	
    button.one("click", first);
	
});
