Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue 

$AdConnection = "AD-Dev-Connection";

try
{
	$today = (Get-Date -Format mm-hh-dd-MM-yyyy)
	$outputCSV = "AD-UserProfile-Mapping-Properties_" + $today + ".csv";

	"Name `t Display Name `t AD Name `t AD Mapping `t Type `t Policy Setting `t Default Private `t Order `t Replicable `t Allow User Edit `t Allow Admin Edit `t Show in Profile Info `t Show in Profile Edit `t Indexed `t Imported from AD `t Exported to AD" | out-file $outputCSV; 
	
	

	# Temp array for Store Mapping Properties
	$propertyMappings = @();
	$propertyMappingsList = New-Object System.Collections.ArrayList($null)

	
	# Get all Stored Property Mappings for a given AD Connection in the ADConnection parameter
	$site = Get-SPSite -Limit 1;    #Get Site for Service context
	$context = Get-SPServiceContext $site;
	$upConfigManager = New-Object Microsoft.Office.Server.UserProfiles.UserProfileConfigManager($context);
	$connectionManager = $upConfigManager.ConnectionManager;
	$connection = $connectionManager[$AdConnection];
	$pmc = $connection.PropertyMapping;
	$emun = $pmc.GetEnumerator();
	while ($emun.MoveNext())
	{
		$pm = $emun.Current;
		
		$tempProp = New-Object System.Object;
		$tempProp | Add-Member -type NoteProperty -name Name -value  $pm.ProfileProperty.Name;
		$tempProp | Add-Member -type NoteProperty -name ADName -value  $pm.OriginalDataSourcePropertyName;
		$tempProp | Add-Member -type NoteProperty -name IsImport -value  $pm.IsImport;
		$tempProp | Add-Member -type NoteProperty -name IsExport -value  $pm.IsExport;
		
		$propertyMappingsList.Add($tempProp) >> null;
		
	}
	
	Write-Host "Property Mapping collected: " + $propertyMappingsList.Count;
	
	# Now we can get all User Profile Properties
	$profileManager = New-Object Microsoft.Office.Server.UserProfiles.UserProfileManager($context);
	$profiles = $profileManager.GetEnumerator();
	#while ($profiles.MoveNext()) 
	#{ 
		$profiles.MoveNext() >> null; #Only iterate thru one user profile
		
		$userProfile = $profiles.Current;
		
		foreach($prop in $userProfile.Properties)
		{
			$name = $prop.Name;
			$displayName = $prop.DisplayName;
			$propType = $prop.CoreProperty.Type;
			$policySetting = $prop.PrivacyPolicy;
			$defatulProvacySetting = $prop.DefaultPrivacy;
			$disaplyOrder = $prop.DisplayOrder;
			$replicable = $prop.TypeProperty.IsReplicable;
			$allowEditUser = $prop.IsUserEditable;
			$allowEditAdmin = $prop.IsAdminEditable;
			$showInProfileInfo = $prop.TypeProperty.IsVisibleOnViewer;
			$showInProfileEdit = $prop.TypeProperty.IsVisibleOnEditor;
			$isIndexed = $prop.CoreProperty.IsSearchable;
			
			$currentMappingProp = $propertyMappingsList | Where {$_.Name -Match $name}
			$adMap = $false;
			$adName = "";
			$importFromAD = "";
			$exportToAD = "";
			
			if ($currentMappingProp -ne $null)
			{
				$adMap = $true;
				$adName = $currentMappingProp.ADName;
				$importFromAD = $currentMappingProp.IsImport;
				$exportToAD = $currentMappingProp.IsExport;
			}
			
			$currentMappingProp = $propertyMappingsList | Where {$_.Name -Match "LastName"}
			"$name `t $displayName `t $adName `t $adMap `t $propType `t $policySetting `t $defatulProvacySetting `t $disaplyOrder `t $replicable `t $allowEditUser `t $allowEditAdmin `t $showInProfileInfo `t $showInProfileEdit `t $isIndexed `t $importFromAD `t $exportToAD"  | Out-File $outputCSV -Append; 

		}
		
	#}
	
	$site.Dispose();
}
catch
{
	Write-Host $_.Exception.ToString()
}
