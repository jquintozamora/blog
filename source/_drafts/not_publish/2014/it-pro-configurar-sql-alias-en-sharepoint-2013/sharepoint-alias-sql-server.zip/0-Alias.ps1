# ===================================================================================
# Func: MatchComputerName
# Desc: Returns TRUE if the $computerName specified matches one of the items in $computersList.
#		Supports wildcard matching (# for a a number, * for any non whitepace character)
# ===================================================================================
Function MatchComputerName($computersList, $computerName)
{
	If ($computersList -like "*$computerName*") { Return $true; }
    foreach ($v in $computersList) {
      If ($v.Contains("*") -or $v.Contains("#")) {
            # wildcard processing
            foreach ($item in -split $v) {
                $item = $item -replace "#", "[\d]"
                $item = $item -replace "\*", "[\S]*"
                if ($computerName -match $item) {return $true;}
            }
        }
    }
}

# ====================================================================================
# Func: Add-SQLAlias
# Desc: Creates a local SQL alias (like using cliconfg.exe) so the real SQL server/name doesn't get hard-coded in SharePoint
#       if local database server is being used, then use Shared Memory protocol
# From: Bill Brockbank, SharePoint MVP (billb@navantis.com)
# ====================================================================================
Function Add-SQLAlias()
{
    <#
    .Synopsis
        Add a new SQL server Alias
    .Description
        Adds a new SQL server Alias with the provided parameters.
    .Example
                Add-SQLAlias -AliasName "SharePointDB" -SQLInstance $env:COMPUTERNAME
    .Example
                Add-SQLAlias -AliasName "SharePointDB" -SQLInstance $env:COMPUTERNAME -Port '1433'
    .Parameter AliasName
        The new alias Name.
    .Parameter SQLInstance
                The SQL server Name os Instance Name
    .Parameter Port
        Port number of SQL server instance. This is an optional parameter.
    #>
    [CmdletBinding(DefaultParameterSetName="BuildPath+SetupInfo")]
    param
    (
        [Parameter(Mandatory=$false, ParameterSetName="BuildPath+SetupInfo")][ValidateNotNullOrEmpty()]
        [String]$aliasName = "SharePointDB",

        [Parameter(Mandatory=$false, ParameterSetName="BuildPath+SetupInfo")][ValidateNotNullOrEmpty()]
        [String]$SQLInstance = $env:COMPUTERNAME,

        [Parameter(Mandatory=$false, ParameterSetName="BuildPath+SetupInfo")][ValidateNotNullOrEmpty()]
        [String]$port = ""
    )

	If ((MatchComputerName $SQLInstance $env:COMPUTERNAME) -or ($SQLInstance.StartsWith($env:ComputerName +"\"))) {
		$protocol = "dbmslpcn" # Shared Memory
	}
	else {
		$protocol = "DBMSSOCN" # TCP/IP
	}

    $serverAliasConnection="$protocol,$SQLInstance"
    If ($port -ne "")
    {
         $serverAliasConnection += ",$port"
    }
    $notExist = $true
    $client = Get-Item 'HKLM:\SOFTWARE\Microsoft\MSSQLServer\Client' -ErrorAction SilentlyContinue
    # Create the key in case it doesn't yet exist
    If (!$client) 
	{
		$client = New-Item 'HKLM:\SOFTWARE\Microsoft\MSSQLServer\Client' -Force
	}
    $client.GetSubKeyNames() | ForEach-Object -Process { If ( $_ -eq 'ConnectTo') { $notExist=$false }}
    If ($notExist)
    {
        $data = New-Item 'HKLM:\SOFTWARE\Microsoft\MSSQLServer\Client\ConnectTo'
    }
    # Add Alias
    $data = New-ItemProperty HKLM:\SOFTWARE\Microsoft\MSSQLServer\Client\ConnectTo -Name $aliasName -Value $serverAliasConnection -PropertyType "String" -Force -ErrorAction SilentlyContinue
}

# ====================================================================================
# Func: CheckSQLAccess
# Desc: Checks if the install account has the correct SQL database access and permissions
# By:   Sameer Dhoot (http://sharemypoint.in/about/sameerdhoot/)
# From: http://sharemypoint.in/2011/04/18/powershell-script-to-check-sql-server-connectivity-version-custering-status-user-permissions/
# Adapted for use in AutoSPInstaller by @brianlala
# ====================================================================================
Function CheckSQLAccess($sqlServer)
{
	If ($sqlServer) # Only check the SQL instance if it has a value
	{
		$objSQLConnection = New-Object System.Data.SqlClient.SqlConnection
		$objSQLCommand = New-Object System.Data.SqlClient.SqlCommand
		Try
		{
			$objSQLConnection.ConnectionString = "Server=$sqlServer;Integrated Security=SSPI;"
			Write-Host -ForegroundColor White " - Testing access to SQL server/instance/alias:" $sqlServer
			Write-Host -ForegroundColor White " - Trying to connect to `"$sqlServer`"..." -NoNewline
			$objSQLConnection.Open() | Out-Null
			Write-Host -ForegroundColor Black -BackgroundColor Green "Success"
			$strCmdSvrDetails = "SELECT SERVERPROPERTY('productversion') as Version"
			$strCmdSvrDetails += ",SERVERPROPERTY('IsClustered') as Clustering"
			$objSQLCommand.CommandText = $strCmdSvrDetails
			$objSQLCommand.Connection = $objSQLConnection
			$objSQLDataReader = $objSQLCommand.ExecuteReader()
			If ($objSQLDataReader.Read())
			{
				Write-Host -ForegroundColor White (" - SQL Server version is: {0}" -f $objSQLDataReader.GetValue(0))
				$SQLVersion = $objSQLDataReader.GetValue(0)
				[int]$SQLMajorVersion,[int]$SQLMinorVersion,[int]$SQLBuild,$null = $SQLVersion -split "\."
				# SharePoint needs minimum SQL 2008 10.0.2714.0 or SQL 2005 9.0.4220.0 per http://support.microsoft.com/kb/976215
				If ((($SQLMajorVersion -eq 10) -and ($SQLMinorVersion -lt 5) -and ($SQLBuild -lt 2714)) -or (($SQLMajorVersion -eq 9) -and ($SQLBuild -lt 4220)))
				{
					Throw " - Unsupported SQL version!"
				}
				If ($objSQLDataReader.GetValue(1) -eq 1)
				{
					Write-Host -ForegroundColor White " - This instance of SQL Server is clustered"
				}
				Else
				{
					Write-Host -ForegroundColor White " - This instance of SQL Server is not clustered"
				}
			}
			$objSQLDataReader.Close()
		}
		Catch
		{
			Write-Host -ForegroundColor Red " - Fail"
			$errText = $error[0].ToString()
			If ($errText.Contains("network-related"))
			{
				Throw " - Connection Error. Check server name, port, firewall."
			}
			ElseIf ($errText.Contains("Login failed"))
			{
				Throw " - Not able to login. SQL Server login not created."
			}
			ElseIf ($errText.Contains("Unsupported SQL version"))
			{
				Throw " - SharePoint 2010 requires SQL 2005 SP3+CU3, SQL 2008 SP1+CU2, or SQL 2008 R2."
			}
			Else
			{
				If (!([string]::IsNullOrEmpty($serverRole)))
				{
					Throw " - $currentUser does not have `'$serverRole`' role!"
				}
				Else {Throw " - $errText"}
			}
		}
	}
}


#### BEGIN CODE ######

#This is the name of your SQL Alias
$AliasConfig = "alias-config-db"
$AliasContent = "alias-content-db"
$AliasServiceApp = "alias-serviceapp-db"
$AliasSearch = "alias-search-db"
 
#This is the name of your SQL server (the actual name!)
$ServerName = "myServerName"
#This is the port to your SQL instance
$sqlport = "1433"
 
#Creating our TCP/IP Aliases
Add-SQLAlias -AliasName $AliasConfig -SQLInstance $ServerName -Port $sqlport
Add-SQLAlias -AliasName $AliasContent -SQLInstance $ServerName -Port $sqlport
Add-SQLAlias -AliasName $AliasServiceApp -SQLInstance $ServerName -Port $sqlport
Add-SQLAlias -AliasName $AliasSearch -SQLInstance $ServerName -Port $sqlport

#Check Access
CheckSQLAccess($AliasConfig);
CheckSQLAccess($AliasContent);
CheckSQLAccess($AliasServiceApp);
CheckSQLAccess($AliasSearch);
