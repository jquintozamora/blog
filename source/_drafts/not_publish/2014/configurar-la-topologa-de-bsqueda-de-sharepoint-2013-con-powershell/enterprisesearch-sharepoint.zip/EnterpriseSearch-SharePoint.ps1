Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue

# Servers
$App01 = "<server 1 FQDN>"
$Web01 = "<server 2 FQDN>"

$SearchAppPoolName = "SharePoint_SearchAppPool"
$SearchAppPoolAccountName = "a\Search_Acount"

$SearchServiceName = "Enterprise Search Service Application"
$SearchServiceProxyName = "Enterprise Search Service Application Proxy"

$DatabaseServer = "alias-search"
$DatabaseName = "SP_EnterpriseSearch"

# Servers - Components Assignment
$adminServer = $App01
$crawlServer = $App01
$analyticsServer = $App01
$contentProcessingServer = $App01
$queryServer = $Web01
$indexServer1 = $App01
$indexServer2 = $Web01



####################  INSTANCE LEVEL CONFIGURATIONS ####################
# Check Enterprise Search Service Instance 1
Write-Host "Checking Enterprise Search Service Instance in $App01" -foreground Green
$SSIApp01 = Get-SPEnterpriseSearchServiceInstance -Identity $App01
if ($SSIApp01 -eq $null)
{
	throw "Unable to retrieve search service on $App01";
}
# Is Search Service Instance Online?
if ($SSIApp01.Status -ne "Online")
{
	Write-Host "Starting Enterprise Search Service Instance in $App01" -foreground Green
	$SSIApp01 | Start-SPEnterpriseSearchServiceInstance 
}
Write-Host "Starting Enterprise Search Query and Site Settings Service Instance in $App01" -foreground Green
Start-SPEnterpriseSearchQueryAndSiteSettingsServiceInstance $App01 -ErrorAction SilentlyContinue

# Check Enterprise Search Service Instance 2
Write-Host "Checking Enterprise Search Service Instance in $Web01" -foreground Green
$SSIWeb01 = Get-SPEnterpriseSearchServiceInstance -Identity $Web01
if ($SSIWeb01 -eq $null)
{
	throw "Unable to retrieve search service on $Web01";
}
# Is Search Service Instance Online?
if ($SSIWeb01.Status -ne "Online")
{
	Write-Host "Starting Enterprise Search Service Instance in $Web01" -foreground Green
	$SSIWeb01 | Start-SPEnterpriseSearchServiceInstance 
}
Write-Host "Starting Enterprise Search Query and Site Settings Service Instance in $Web01" -foreground Green
Start-SPEnterpriseSearchQueryAndSiteSettingsServiceInstance $Web01 -ErrorAction SilentlyContinue 
########################################################################


####################  SERVICE LEVEL CONFIGURATIONS #####################
Write-Host "Changing Enterprise Search Service Configurations (account, ...)" -foreground Green
$cred = Get-Credential $SearchAppPoolAccountName
$SearchService = Get-SPEnterpriseSearchService
Set-SPEnterpriseSearchService `
   -Identity $SearchService `
   -ServiceAccount $cred.UserName `
   -ServicePassword $cred.Password `
   -ContactEmail "searchadmin@company" `
   -ConnectionTimeout "60" `
   -AcknowledgementTimeout "60" `
   -ProxyType "Default" `
   -PerformanceLevel "Maximum"
########################################################################


##############  SERVICE APPLICATION LEVEL CONFIGURATIONS ###############
Write-Host "Checking Enterprise Search Service Application" -foreground Green
$searchServiceApp = Get-SPEnterpriseSearchServiceApplication $SearchServiceName -ErrorAction SilentlyContinue
 
if ($searchServiceApp -eq $null)
{
	$saAppPool = Get-SPServiceApplicationPool | where { $_.Name -eq $SearchAppPoolName }
	if ($saAppPool -eq $null)
	{
		Write-Host "Creating Search Application Pool $SearchAppPoolName" -foreground Green
		$saAppPool = New-SPServiceApplicationPool -Name $SearchAppPoolName -Account $SearchAppPoolAccountName -Verbose
	}
	$searchServiceApp = New-SPEnterpriseSearchServiceApplication -Name $SearchServiceName -ApplicationPool $saAppPool -DatabaseServer $DatabaseServer -DatabaseName $DatabaseName
	Write-Host "Search Service Application Created ($SearchServiceName)" -foreground Green
}
else
{
	throw "Search Service Application $SearchServiceName has been previously created.";
}
########################################################################


####################  SEARCH TOPOLOGY CONFIGURATIONS ###################
Write-Host "Checking Initial Search Topology" -foreground Green
$initialSearchTopology = ($searchServiceApp | Get-SPEnterpriseSearchTopology)
Write-Host "Creating a new Search Topology" -foreground Green
$newSearchTopology = New-SPEnterpriseSearchTopology -SearchApplication $searchServiceApp

# Admin Component
Write-Host "Creating a new Search Topology: Admin Component" -foreground Green
New-SPEnterpriseSearchAdminComponent �SearchTopology $newSearchTopology -SearchServiceInstance $SSIApp01

# Content Processing Component
Write-Host "Creating a new Search Topology: Content Processing Component" -foreground Green
New-SPEnterpriseSearchContentProcessingComponent �SearchTopology $newSearchTopology -SearchServiceInstance $SSIApp01
#New-SPEnterpriseSearchContentProcessingComponent �SearchTopology $newSearchTopology -SearchServiceInstance $App2SSI

# Analytics processing component
Write-Host "Creating a new Search Topology: Analytic Processing Component" -foreground Green
New-SPEnterpriseSearchAnalyticsProcessingComponent �SearchTopology $newSearchTopology -SearchServiceInstance $SSIApp01

# Crawl component
Write-Host "Creating a new Search Topology: Crawl Component" -foreground Green
New-SPEnterpriseSearchCrawlComponent �SearchTopology $newSearchTopology -SearchServiceInstance $SSIApp01

# Query Processing Component
Write-Host "Creating a new Search Topology: Query Processing Component" -foreground Green
New-SPEnterpriseSearchQueryProcessingComponent �SearchTopology $newSearchTopology -SearchServiceInstance $SSIWeb01

# Two Index Replica
#Set the primary and replica index location; ensure these drives and folders exist on application servers and they are EMPTY!
$PrimaryIndexLocation = "E:\Media\Search\Index" 
$ReplicaIndexLocation = "E:\Media\Search\Index"
Write-Host "Creating a new Search Topology: IndexComponent And Replica" -foreground Green
New-SPEnterpriseSearchIndexComponent �SearchTopology $newSearchTopology -SearchServiceInstance $SSIApp01 -RootDirectory $PrimaryIndexLocation -IndexPartition 0
New-SPEnterpriseSearchIndexComponent �SearchTopology $newSearchTopology -SearchServiceInstance $SSIWeb01 -RootDirectory $ReplicaIndexLocation -IndexPartition 0

Write-Host "Activating the new Search Topology" -foreground Green
$newSearchTopology.Activate()

Write-Host "Removing the old Search Topology" -foreground Green
Remove-SPEnterpriseSearchTopology -SearchApplication $searchServiceApp -Identity $initialSearchTopology 

Write-Host "Creating Proxy" -foreground Green
$searchProxy = New-SPEnterpriseSearchServiceApplicationProxy -Name $SearchServiceProxyName -SearchApplication $searchServiceApp 

########################################################################

Write-Host "Checking new Enterprise Search Service" -foreground Green
$ssa = Get-SPEnterpriseSearchServiceApplication
Get-SPEnterpriseSearchTopology -Active -SearchApplication $ssa



