using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Data;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Publishing;
using Microsoft.SharePoint.WebPartPages;
using System.Collections.Generic;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Text;
using System.Runtime.Serialization;

namespace EA.PS2010.SPS.ProjectSiteLists.WebParts.ProjectSiteLists
{
    [ToolboxItemAttribute(false)]
    public class ProjectSiteLists : Microsoft.SharePoint.WebPartPages.WebPart
    {

        private string _contentType = String.Empty;
        [WebBrowsable(true), Personalizable(PersonalizationScope.Shared, false), Category("Filters"), Description("Apply filters to search")]
        public string ContentType
        {
            get { return _contentType; }
            set { _contentType = value; }
        }

        private string _fieldsNames = String.Empty;
        [WebBrowsable(true), Personalizable(PersonalizationScope.Shared, false), Category("Filters"), Description("Apply filters to search")]
        public string FieldsNames
        {
            get { return _fieldsNames; }
            set { _fieldsNames = value; }
        }


        private string[] _fieldsArray = null;
        private string[] FieldsArray
        {
            get
            {
                if (string.IsNullOrEmpty(FieldsNames))
                {
                    _fieldsArray = getFieldsNames(FieldsNames);
                }
                return _fieldsArray;
            }
            set { _fieldsArray = value; }
        }

        //Used this article for cache data: http://zimmergren.net/technical/web-part-caching-a-simple-approach

        private string CACHE_KEY = String.Concat("ListAggregator_Cache", HttpContext.Current.Request.Url.AbsolutePath);
        private const int CACHE_MINUTES = 10;

        private char[] _sep = { ',' };
        private string[] _filterSeparator = { "AND" };

        private SPGridView oGrid;
        private ObjectDataSource gridDS;
        private DataTable newTable = new DataTable();
        LinkButton oBtn_Export;

        string FilterExpression
        {
            get
            {
                if (ViewState["FilterExpression"] == null)
                {
                    ViewState["FilterExpression"] = "";
                }

                return (string)ViewState["FilterExpression"];
            }
            set
            {
                string newFilter = value.ToString().Trim(new char[] { '(', ')' });
                newFilter = "(" + newFilter + ")";
                List<string> expressionList = new List<string>();

                if (ViewState["FilterExpression"] != null)
                {
                    string filtering = ViewState["FilterExpression"].ToString();
                    string[] splitFiltering = filtering.Split(_filterSeparator, StringSplitOptions.RemoveEmptyEntries);
                    expressionList.AddRange(splitFiltering);

                    //if the filter is gone expression already exist?
                    int index = expressionList.FindIndex(s => s.Contains(newFilter));
                    if (index == -1)
                    {
                        //TODO: need to refactor the support for multiple filters on same column as OR or IN
                        expressionList.Add(newFilter);
                    }
                }
                else
                {
                    expressionList.Add(newFilter);
                }
                //loop through the list<T> and serialize to string
                string filterExpression = string.Empty;
                expressionList.ForEach(s => filterExpression += s + " AND ");
                filterExpression = filterExpression.Remove(filterExpression.LastIndexOf(" AND "));
                if (!filterExpression.EndsWith("))") && filterExpression.Contains("AND"))
                {
                    filterExpression = "(" + filterExpression + ")";
                }
                ViewState["FilterExpression"] = filterExpression;
            }
        }

        string SortExpression
        {
            get
            {
                if (ViewState["SortExpression"] == null)
                {
                    ViewState["SortExpression"] = "";
                }

                return (string)ViewState["SortExpression"];
            }
            set
            {
                string newSort = value.ToString();
                string[] split = newSort.Split(' ');
                string sortField = split[0];
                List<string> expressionList = new List<string>();

                if (ViewState["SortExpression"] != null)
                {
                    string sorting = ViewState["SortExpression"].ToString();
                    string[] splitSorting = sorting.Split(_sep);
                    expressionList.AddRange(splitSorting);

                    //does the sort expression already exist?
                    int index = expressionList.FindIndex(s => s.Contains(sortField));
                    if (index >= 0)
                    {
                        string sort = string.Empty;
                        if (newSort.Contains("DESC"))
                        {
                            sort = newSort;
                        }
                        else
                        {
                            sort = expressionList[index];
                            if (sort.Contains("ASC"))
                            {
                                sort = sort.Replace("ASC", "DESC");
                            }
                            else
                            {
                                sort = sort.Replace("DESC", "ASC");
                            }
                        }
                        //reset the sort direction
                        expressionList[index] = sort;
                    }
                    else
                    {

                        if (newSort.Contains("DESC"))
                        {
                            expressionList.Add(newSort);
                        }
                        else
                        {
                            expressionList.Add(sortField + " ASC");
                        }
                    }
                }
                else
                {
                    if (newSort.Contains("DESC"))
                    {
                        expressionList.Add(newSort);
                    }
                    else
                    {
                        expressionList.Add(sortField + " ASC");
                    }
                }
                //loop through the list<T> and serialize to string
                string sortExpression = string.Empty;
                expressionList.ForEach(s => sortExpression += s);
                sortExpression = sortExpression.Replace(" ASC", " ASC,");
                sortExpression = sortExpression.Replace(" DESC", " DESC,");
                ViewState["SortExpression"] = sortExpression.Remove(sortExpression.LastIndexOf(','));
            }
        }


        public ProjectSiteLists()
        {
            this.ExportMode = WebPartExportMode.All;
        }


        protected override void LoadViewState(object savedState)
        {
            base.LoadViewState(savedState);

            if (Context.Request.Form["__EVENTARGUMENT"] != null &&
                 Context.Request.Form["__EVENTARGUMENT"].Contains("__ClearFilter__"))
            {
                // Clear FilterExpression
                ViewState.Remove("FilterExpression");
            }
        }

        public DataTable PopulateDatasetSPSiteDataQuery(string sortExpression, string contentType, string fieldsNames)
        {
            if (!string.IsNullOrEmpty(contentType))
            {
                if (HttpRuntime.Cache[CACHE_KEY] == null)
                {
                    string status = "The following items are <strong>NOT</strong> fetched from the cache<br/><br/>";
                    //In order to know all field Internal Names: $dependenciesList.Fields | Select InternalName
                    SPSiteDataQuery q = new SPSiteDataQuery();
                    string[] fields = getFieldsNames(fieldsNames);

                    string nameField, typeField;

                    q.ViewFields = "<FieldRef Name='Title' />";
                    q.ViewFields += "<FieldRef Name='Team' Type='Lookup' Nullable='True' />";

                    if (fields != null)
                    {
                        for (int i = 0; i < fields.Length; i++)
                        {
                            nameField = fields[i].Split(',')[1].ToString();
                            typeField = fields[i].Split(',')[2].ToString();
                            q.ViewFields += String.Concat("<FieldRef Name='", nameField, "' Type='", typeField, "' Nullable='True' />");
                        }
                    }


                    q.ViewFields += "<FieldRef Name='FileDirRef'  Nullable='True' />";
                    q.Lists = "<Lists ServerTemplate='100' BaseType='0' MaxListLimit='0' />"; // tipo de objeto donde queremos buscar. GenericList = 0, DocumentLibrary = 1, DiscussionForum = 3, VoteOfSurvey = 4, IssueList = 5
                    q.Webs = "<Webs Scope='SiteCollection' />"; // alcance de la busqueda

                    q.Query = String.Concat("<Where><Eq><FieldRef Name='ContentType' /><Value Type='Text'>", contentType, "</Value></Eq></Where>"); // query CAML

                        using (SPWeb w = new SPSite(String.Concat(HttpContext.Current.Request.Url.Scheme, "://", HttpContext.Current.Request.Url.Authority, "/PWA/")).OpenWeb())
                        {
                            DataTable oDataTable = new DataTable();
                            using (SPMonitoredScope populateDataSet = new SPMonitoredScope("GetSiteData_PopulateData"))
                            {
                                try
                                {
                                    oDataTable = w.GetSiteData(q);
                                    Logger.LogInfo(Logger.Constants.LogSource.LOGSRC_COMMON, "Number of items from GetSiteData_PopulateData: " + oDataTable.Rows.Count);
                                }
                                catch (Exception)
                                {
                                    oDataTable = null;

                                }

                            }

                            if (oDataTable != null)
                            {
                                newTable.Columns.Add("ProjectName");
                                foreach (DataColumn col in oDataTable.Columns) // Loop over the rows.
                                {
                                    newTable.Columns.Add(col.ColumnName);
                                }

                                foreach (DataRow row in oDataTable.Rows) // Loop over the items.
                                {
                                    DataRow newRow = newTable.Rows.Add();

                                    newRow["ProjectName"] = row["FileDirRef"].ToString().Split('/')[1];
                                    foreach (DataColumn col in oDataTable.Columns) // Loop over the rows.
                                    {
                                        string initialValue = row[col.ColumnName].ToString();
                                        string finalValue = initialValue;
                                        if (!string.IsNullOrEmpty(initialValue))
                                        {
                                            if (col.ColumnName.Equals("Team") || col.ColumnName.Equals("Depends_x0020_On"))
                                            {
                                                try
                                                {
                                                    SPFieldLookupValue lookupGroup = new SPFieldLookupValue(initialValue);
                                                    finalValue = lookupGroup.LookupValue;
                                                }
                                                catch (Exception) { }
                                            }
                                            if (col.ColumnName.Equals("Due_x0020_Date") || col.ColumnName.Equals("DueDate"))
                                            {
                                                finalValue = "";
                                                DateTime date;
                                                if (DateTime.TryParse(row[col.ColumnName].ToString(), out date))
                                                {
                                                    finalValue = date.ToString("dd/MM/yyyy");
                                                }

                                            }
                                            if (col.ColumnName.Equals("AssignedTo"))
                                            {
                                                try
                                                {
                                                    SPFieldUserValue userValue = new SPFieldUserValue(w, initialValue);
                                                    finalValue = userValue.LookupValue;
                                                }
                                                catch (Exception) { }
                                            }
                                      
                                        }
                                        newRow[col.ColumnName] = finalValue;

                                    }
                                }
                            }
                        }

                        HttpRuntime.Cache.Add(CACHE_KEY,
                        newTable,
                        null,
                        DateTime.MaxValue,
                        TimeSpan.FromMinutes(CACHE_MINUTES),
                        System.Web.Caching.CacheItemPriority.Default, null);
                }
                else
                {
                    string status = "The following items <strong>ARE</strong> fetched from the cache!<br/><br/>";
                    newTable = (DataTable)HttpRuntime.Cache[CACHE_KEY];
                }
            }

            //clean up the sort expression if needed - the sort descending 
            //menu item causes the double in some cases 
            if (sortExpression.ToLowerInvariant().EndsWith("desc desc"))
                sortExpression = sortExpression.Substring(0, sortExpression.Length - 5);

            //need to handle the actual sorting of the data
            if (!string.IsNullOrEmpty(sortExpression))
            {
                try
                {
                    DataView view = new DataView(newTable);
                    view.Sort = sortExpression;
                    DataTable newTable2 = view.ToTable();
                    newTable.Clear();
                    newTable.Merge(newTable2);
                }
                catch (Exception ex)
                {
                    LiteralControl literal = new LiteralControl(string.Concat("SortExpression: ", ex.ToString()));
                    this.Controls.Add(literal);
                }
            }


            return newTable;
        }

        protected override void CreateChildControls()
        {
            //http://sharethefrustration.blogspot.com.es/2010/02/spgridview-webpart-with-multiple-filter.html
            //http://www.c-sharpcorner.com/UploadFile/sagarp/js-grid-control-sharepoint/
            //http://sharepoint.stackexchange.com/questions/5207/spgridview-sorting-filtering-and-paging
            try
            {

                oBtn_Export = new LinkButton();
                oBtn_Export.ID = "btn_export";
                oBtn_Export.Text = "Export to Excel";
                oBtn_Export.CssClass = "ms-cui-ctl-large";
                oBtn_Export.Controls.Add(new LiteralControl("<SPAN class='ms-cui-ctl-largeIconContainer'><SPAN class='ms-cui-img-32by32 ms-cui-img-cont-float'><IMG style='LEFT: 0px; TOP: -352px;border: 0px;' alt='' src='/_layouts/1033/images/formatmap32x32.png' ></SPAN></SPAN><SPAN class='ms-cui-ctl-largelabel' >Export to<BR>Excel</SPAN>"));
                // that is needed in order to allow page be enabled after Download
                oBtn_Export.OnClientClick = "_spFormOnSubmitCalled = false;_spSuppressFormOnSubmitWrapper=true;";
                oBtn_Export.Click += new EventHandler(oBtn_Export_Click);
                this.Controls.Add(oBtn_Export);

                // Notice that PopulateDatasetSPSiteDataQuery is called from this.Controls
                gridDS = new ObjectDataSource();
                gridDS.ID = "gridDS";
                gridDS.SelectMethod = "PopulateDatasetSPSiteDataQuery";
                gridDS.TypeName = this.GetType().AssemblyQualifiedName;
                gridDS.EnableViewState = false;
                gridDS.SortParameterName = "SortExpression";
                gridDS.SelectParameters.Add("contentType", ContentType);
                gridDS.SelectParameters.Add("fieldsNames", FieldsNames);
                gridDS.FilterExpression = FilterExpression;
                this.Controls.Add(gridDS);


                oGrid = new SPGridView();
                oGrid.ID = "oGrid";
                oGrid.AutoGenerateColumns = false;
                oGrid.EnableViewState = false;

                //Disable Pagging
                oGrid.AllowPaging = false;

                // Sorting Code
                oGrid.AllowSorting = true;

                //filtering 
                oGrid.AllowFiltering = true;

                StringBuilder filterDataFields = new StringBuilder();
                FieldsArray = getFieldsNames(FieldsNames);
                filterDataFields.Append("ProjectName");             
                filterDataFields.Append(",");
                filterDataFields.Append("Title");

                //Fields in Object Data Source = ProjectName, ListId, WebId, ID, Title, Team, Depends_x0020_On, Due_x0020_Date, Status, FileDirRef, Notes
                if (FieldsArray != null)
                {
                    for (int i = 0; i < FieldsArray.Length; i++)
                    {
                       string field = FieldsArray[i].Split(',')[1].ToString();
                       if (!field.Equals("Notes"))
                       {
                           filterDataFields.Append(",");
                           filterDataFields.Append(field);
                       }
                    }
                }
                //oGrid.FilterDataFields = "ProjectName,Title,Team,Depends_x0020_On,Due_x0020_Date,Status";
                oGrid.FilterDataFields = filterDataFields.ToString();
                oGrid.FilteredDataSourcePropertyName = "FilterExpression";
                oGrid.FilteredDataSourcePropertyFormat = "{1} = '{0}'";

                oGrid.Sorting += new GridViewSortEventHandler(gridView_Sorting);
                oGrid.RowDataBound += new GridViewRowEventHandler(gridView_RowDataBound);

                AddColumnsToSPGridView();

                //TODO: 
                //Add logic to make a custom data set and preprocess the information adapting the texts 
                // and providing a new field called Project.

                oGrid.DataSourceID = gridDS.ID;

                // Add Control to Page
                Controls.Add(oGrid);

                //using (SPMonitoredScope databindScope = new SPMonitoredScope("DataBind"))
                //{
                //    oGrid.DataBind();
                //}
                //base.CreateChildControls();
            }
            catch (ParseException ex)
            {
                LiteralControl literal = new LiteralControl();
                literal.Text = ex.Message;
                this.Controls.Add(literal);
            }

        }

        void AddColumnsToSPGridView()
        {
            string dataField, headerText, sortExpression;

            SPBoundField colTitle1 = new SPBoundField();
            colTitle1.DataField = "ProjectName";
            colTitle1.HeaderText = "Project Name";
            colTitle1.SortExpression = "ProjectName";
            oGrid.Columns.Add(colTitle1);


            SPBoundField colTitle = new SPBoundField();
            colTitle.DataField = "Title";
            colTitle.HeaderText = "Title";
            colTitle.SortExpression = "Title";
            oGrid.Columns.Add(colTitle);





            if (FieldsArray != null)
            {
                for (int i = 0; i < FieldsArray.Length; i++)
                {

                    dataField = FieldsArray[i].Split(',')[1];
                    headerText = FieldsArray[i].Split(',')[0];
                    sortExpression = FieldsArray[i].Split(',')[1];

                    if (headerText.Equals("Notes"))
                    {
                        BoundField colNotes = new BoundField();
                        colNotes.HtmlEncode = false;
                        colNotes.DataField = dataField;
                        colNotes.HeaderText = headerText;
                        colNotes.SortExpression = sortExpression;
                        oGrid.Columns.Add(colNotes);
                    }
                    else
                    {
                        SPBoundField colName = new SPBoundField();
                        colName.DataField = dataField;
                        colName.HeaderText = headerText;
                        colName.SortExpression = sortExpression;
                        oGrid.Columns.Add(colName);
                    }
                 
                
                }
            }
        }

        private void oBtn_Export_Click(object sender, EventArgs e)
        {


            oGrid.AllowPaging = false;
            oGrid.AllowSorting = false;
            oGrid.AllowFiltering = false;

            System.IO.MemoryStream stream = new System.IO.MemoryStream();
            using (SpreadsheetDocument document = SpreadsheetDocument.Create(stream, SpreadsheetDocumentType.Workbook, true))
            {
                DataSet ds = new DataSet();
                var dv = (DataView)gridDS.Select();
                if (dv != null && dv.Count > 0)
                {
                    DataTable dt = dv.ToTable();
                    //Check to hide columns
                    List<String> columnsInGrid = new List<string>();
                    if (oGrid.HeaderRow != null)
                    {
                        for (int i = 0; i < oGrid.HeaderRow.Cells.Count; i++)
                        {
                            DataControlFieldHeaderCell headerfield = oGrid.HeaderRow.Cells[i] as DataControlFieldHeaderCell;
                            DataControlField spbf = headerfield.ContainingField as DataControlField;
                            //Notice that SortException allways must be the same that DataField
                            columnsInGrid.Add(spbf.SortExpression); //["DataField"]);
                        }
                    }
                    for (int i = dt.Columns.Count - 1; i >= 0; i--)
                    {
                        if (!columnsInGrid.Contains(dt.Columns[i].ToString()))
                        {
                            dt.Columns.RemoveAt(i);
                        }
                    }
                    ds.Tables.Add(dt);
                }
                ExportExcel.WriteExcelFile(ds, document);

            }
            stream.Flush();
            stream.Position = 0;

            Page.Response.ClearContent();
            Page.Response.Clear();
            Page.Response.ClearHeaders();
            Page.Response.Buffer = true;
            Page.Response.Charset = "";

            //  NOTE: If you get an "HttpCacheability does not exist" error on the following line, make sure you have
            //  manually added System.Web to this project's References.
            string filename = "DependenciesReport.xlsx";

            Page.Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
            Page.Response.AddHeader("content-disposition", "attachment; filename=" + filename);
            Page.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Page.Response.AddHeader("Content-Length", stream.Length.ToString());

            byte[] data1 = new byte[stream.Length];
            stream.Read(data1, 0, data1.Length);
            stream.Close();
            Page.Response.BinaryWrite(data1);
            Page.Response.Flush();
            Page.Response.End();

        }


        protected override void OnPreRender(EventArgs e)
        {           
            if (!Page.IsPostBack)
            {
                try
                {
                    oGrid.DataBind();
                }
                catch (Exception ex)
                {
                    LiteralControl literal = new LiteralControl();
                    literal.Text = ex.Message;
                }
            }

            //make sure the header images are set
            buildFilterView(gridDS.FilterExpression);
        }

        private void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (sender == null || e.Row.RowType != DataControlRowType.Header)
            { return; }

            SPGridView grid = sender as SPGridView;

            // Show icon on filtered and sorted columns 
            for (int i = 0; i < grid.Columns.Count; i++)
            {
                DataControlField field = grid.Columns[i];
                e.Row.Cells[i].Attributes.Add("style", "height: 21px;");

                if (FilterExpression.Contains(field.SortExpression) &&
                    !string.IsNullOrEmpty(FilterExpression))
                {
                    PlaceHolder panel = HeaderImages(field, "/_layouts/images/filter.gif");

                    try
                    {
                        e.Row.Cells[i].Controls[0].Controls.Add(panel);

                    }
                    catch
                    {
                    }
                }
                else if (SortExpression.Contains(field.SortExpression))
                {
                    string url = sortImage(field);
                    PlaceHolder panel = HeaderImages(field, url);
                    try
                    {
                        e.Row.Cells[i].Controls[0].Controls.Add(panel);
                    }
                    catch
                    {
                    }
                }
            }
        }


        private string sortImage(DataControlField field)
        {
            string url = string.Empty;
            string[] fullSortExp = SortExpression.Split(_sep);
            List<string> fullSortExpression = new List<string>();
            fullSortExpression.AddRange(fullSortExp);

            //does the sort expression already exist?
            int index = fullSortExpression.FindIndex(s => s.Contains(field.SortExpression));
            if (index >= 0)
            {
                string s = fullSortExpression[index];
                if (s.Contains("ASC"))
                { url = "_layouts/images/sortup.gif"; }
                else
                { url = "_layouts/images/sortdown.gif"; }
            }
            return url;
        }


        private PlaceHolder HeaderImages(DataControlField field, string imageUrl)
        {
            Image filterIcon = new Image();
            filterIcon.ImageUrl = imageUrl;
            filterIcon.Style[HtmlTextWriterStyle.MarginLeft] = "2px";

            Literal headerText = new Literal();
            headerText.Text = field.HeaderText;

            PlaceHolder panel = new PlaceHolder();
            panel.Controls.Add(headerText);

            //add the sort icon if needed
            if (FilterExpression.Contains(field.SortExpression) &&
                SortExpression.Contains(field.SortExpression))
            {
                string url = sortImage(field);
                Image sortIcon = new Image();
                sortIcon.ImageUrl = url;
                sortIcon.Style[HtmlTextWriterStyle.MarginLeft] = "1px";
                panel.Controls.Add(sortIcon);
                //change the left margin to 1
                filterIcon.Style[HtmlTextWriterStyle.MarginLeft] = "1px";
            }

            panel.Controls.Add(filterIcon);
            return panel;
        }


        void gridView_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sDir = e.SortDirection.ToString();
            sDir = sDir == "Descending" ? " DESC" : "";

            SortExpression = e.SortExpression + sDir;
            e.SortExpression = SortExpression;

            //keep the filter
            if (!string.IsNullOrEmpty(FilterExpression))
            { gridDS.FilterExpression = FilterExpression; }

        }


        void buildFilterView(string filterExp)
        {
            string lastExp = filterExp;
            if (lastExp.Contains("AND"))
            {
                if (lastExp.Length < lastExp.LastIndexOf("AND") + 4)
                { lastExp = lastExp.Substring(lastExp.LastIndexOf("AND") + 4); }
                else
                { lastExp = string.Empty; }
            }

            //update the filter
            if (!string.IsNullOrEmpty(lastExp))
            { FilterExpression = lastExp; }

            //reset object dataset filter
            if (!string.IsNullOrEmpty(FilterExpression))
            {
                gridDS.FilterExpression = FilterExpression;
                string a = gridDS.FilterParameters.ToString();
                gridDS.FilterParameters.Add("Status", "Closed");
            }
        }

        /// <summary>
        /// Array separated by ';'. Each position is separated by ','.
        /// Array[i][0]-> Name
        /// Array[i][1]-> Data Field/Sort Expression
        /// Array[i][2]-> Field type
        /// </summary>
        /// <param name="fieldsNames">Formatted array</param>
        /// <returns></returns>
        private string[] getFieldsNames(string fieldsNames)
        {

            string[] arrFieldsNames = null;
            char separator = ';';
            char lastCharacter;
            try
            {
                if (!String.IsNullOrEmpty(fieldsNames))
                {
                    fieldsNames = fieldsNames.Trim();

                    if (fieldsNames.Contains(separator.ToString()))
                    {
                        lastCharacter = fieldsNames[fieldsNames.Length - 1];

                        if (lastCharacter.Equals(';'))
                        {
                            fieldsNames = fieldsNames.Remove(fieldsNames.Length - 1);
                            arrFieldsNames = fieldsNames.Split(separator);
                            for (int i = 0; i < arrFieldsNames.Length; i++)
                            {
                                if (arrFieldsNames[i].Split(',').Length != 3)
                                {
                                    throw new ParseException();
                                }
                            }
                        }
                        else
                        {
                            throw new ParseException();
                        }

                    }
                    else
                    {
                        throw new ParseException();
                    }
                }
            }
            catch (ParseException)
            {
                throw new ParseException("Field values couldn't be parsed");
            }

            return arrFieldsNames;
        }
     

    }

    [Serializable]
    public class ParseException : Exception
    {
        public ParseException()
            : base() { }

        public ParseException(string message)
            : base(message) { }

        public ParseException(string format, params object[] args)
            : base(string.Format(format, args)) { }

        public ParseException(string message, Exception innerException)
            : base(message, innerException) { }

        public ParseException(string format, Exception innerException, params object[] args)
            : base(string.Format(format, args), innerException) { }

        protected ParseException(SerializationInfo info, StreamingContext context)
            : base(info, context) { }
    }
}



