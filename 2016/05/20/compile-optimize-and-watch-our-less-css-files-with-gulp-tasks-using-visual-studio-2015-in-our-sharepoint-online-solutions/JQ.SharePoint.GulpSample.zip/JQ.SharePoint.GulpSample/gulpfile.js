﻿/// <binding BeforeBuild='css-optimize' />

/*************************************************************************
 * Gulp file (gulpfile.js)
 *************************************************************************
 * @description
 * Gulpfile where all the Gulp tasks are created. In this case intented 
 * to compile, optimize and upload to SharePoint LESS / CSS files
 * 
 * @author
 *  José Quinto http://josharepoint.com
 *************************************************************************/


"use strict";

/////////////////////////////////////////////////
//                  IMPORTS
/////////////////////////////////////////////////
var gulp = require('gulp');
// Module to lazy loading modules, just call $.<moduleName>() in your gulp tasks
var $ = require('gulp-load-plugins')({ lazy: true });
// Config is a function because it was assidgned to be a function in gulp.config.js file
var config = require('./gulp.config')();


/////////////////////////////////////////////////
//           GULP TASKS FOR LESS/CSS
/////////////////////////////////////////////////

gulp.task("css-upload-to-sharepoint", ['css-optimize'], function () {
    log('Uploading CSS min files to SharePoint');
    // Non - Themable files
    uploadToSharePoint(config.lessConfig.UploadSPNonThemableFiles, config.lessConfig.UploadSPNonThemableFolder);
    // Themable files
    uploadToSharePoint(config.lessConfig.UploadSPThemableFiles, config.lessConfig.UploadSPThemableFolder);
});

gulp.task('css-optimize', ['less-compile'], function () {
    log('Optimizing CSS');
    return gulp
        .src([config.lessConfig.LessOutPutFolder + '/*.css', '!' + config.lessConfig.LessOutPutFolder + '/*.min.css'])
        .pipe($.csso())
        .pipe($.rename({
            suffix: '.min'
        }))
        .pipe($.print(function (filepath) {
            return $.util.colors.green("Dest (min): " + filepath);
        }))
        .pipe(gulp.dest(config.lessConfig.LessOutPutFolder));
});

gulp.task('less-compile', function () {
    log('Compiling Less --> CSS');
    return gulp
        .src(config.lessConfig.LessFiles)
        .pipe($.print(function (filepath) {
            return "Source:     " + filepath;
        }))
        .pipe($.less())
        .pipe($.autoprefixer({ browsers: ['last 2 version', '> 5%'] }))
        .pipe(gulp.dest(config.lessConfig.LessOutPutFolder))
        .pipe($.print(function (filepath) {
            return $.util.colors.green("Dest:       " + filepath);
        }));
});

gulp.task('watcher-less', function () {
    gulp.watch(config.lessConfig.LessFolder + '/*.less', ['css-upload-to-sharepoint']);
});


///////////////////////////////////////
//      UTILITY FUNCTIONS
///////////////////////////////////////
function uploadToSharePoint(files, spFolder) {
    var user = config.UserConfig[process.env.USERNAME];
    gulp.src(files)
       .pipe($.spsave({
           username: user.userName,
           password: user.passWord,
           siteUrl: user.siteUrl,
           folder: spFolder,
           checkin: true,
           checkinType: 1
       }));
}
function log(msg) {
    if (typeof (msg) === 'object') {
        for (var item in msg) {
            if (msg.hasOwnProperty(item)) {
                $.util.log($.util.colors.blue(msg[item]));
            }
        }
    } else {
        $.util.log($.util.colors.blue(msg));
    }
}
