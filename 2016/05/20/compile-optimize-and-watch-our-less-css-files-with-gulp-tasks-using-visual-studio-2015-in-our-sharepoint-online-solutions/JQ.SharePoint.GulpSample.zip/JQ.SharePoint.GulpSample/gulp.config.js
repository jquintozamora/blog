﻿/*************************************************************************
 * Gulp configuration file (gulp.config.js)
 *************************************************************************
 * @description
 * Configuration file used by gulpfile.js to use variables, consts, etc.
 * 
 * @author
 *  José Quinto http://josharepoint.com
 *************************************************************************/
module.exports = function () {

    // Config Global Variables
    var assetsPath = './Modules/MO_Assets/';

    // Config Returned Object to be used in gulpfile.js
    var config = {

        UserConfig: {
            "LocalMachineUser": {
                userName: "user@<tenant>.onmicrosoft.com",
                passWord: "pass",
                siteUrl: "https://<tenant>.sharepoint.com/sites/jqtest"
            }
        },
        lessConfig: {
            LessFolder: assetsPath + "Styles/LESS",
            LessOutPutFolder: assetsPath + "Styles/Output",
            LessFiles: [
              assetsPath + "Styles/LESS/JQ.MasterPage.less",
              assetsPath + "Styles/LESS/JQ.Themable.less"
            ],
            UploadSPNonThemableFiles: [
              assetsPath + "Styles/Output/JQ.MasterPage.min.css"
            ],
            UploadSPNonThemableFolder: "Style Library/Styles",
            UploadSPThemableFiles: [
              assetsPath + "Styles/Output/JQ.Themable.min.css"
            ],
            UploadSPThemableFolder: "Style Library/en-us/themable"
        }
    };
    return config;
};

